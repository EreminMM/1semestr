﻿using System;

class Program
{
    static void Main()
    {
        Console.Write("Введите целое число N: ");
        int N = Convert.ToInt32(Console.ReadLine());
        int a = 1;
        int b = 1;
        int k = 2;
        if (N == 1)
        {
            Console.WriteLine("Порядковый номер K: 1 или 2 (F(1) = F(2) = 1)");
            return;
        }
        while (b < N)
        {
            int next = a + b;
            a = b;
            b = next;
            k++;
        }
        if (b == N)
        {
            Console.WriteLine("Порядковый номер K: " + k);
        }
        else
        {
            Console.WriteLine("Число не является числом Фибоначчи или меньше 1.");
        }
    }
}
﻿using System;

class Program
{
    static void Main()
    {
        double initialDistance = 10.0;
        double totalDistance = 0.0;
        int days = 0;
        Console.Write("Введите P: ");
        double P = Convert.ToDouble(Console.ReadLine());
        if (P <= 0 || P >= 50)
        {
            Console.WriteLine("P должно быть в пределах (0, 50).");
            return;
        }
        double increaseFactor = 1 + (P / 100);
        double dailyDistance = initialDistance;
        while (totalDistance <= 200)
        {
            days++;
            totalDistance += dailyDistance;
            dailyDistance *= increaseFactor;
        }
        Console.WriteLine($"Количество дней: {days}");
        Console.WriteLine($"Суммарный пробег: {totalDistance:F2} км");
    }
}
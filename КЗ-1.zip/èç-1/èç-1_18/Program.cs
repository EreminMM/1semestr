﻿using System;

class Program
{
    static void Main()
    {
        Console.Write("Введите целое число n: ");
        int n = Convert.ToInt32(Console.ReadLine());
        double sum = 0;
        for (int i = 1; i <= n; i++)
        {
            double term = 1 + 0.1 * i;
            sum += term;
        }
        Console.WriteLine(sum);
    }
}
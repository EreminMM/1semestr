﻿using System;

class Program
{
    static void Main()
    {
        Console.Write("Введите целое число n: ");
        int n = Convert.ToInt32(Console.ReadLine());
        double result = 0;
        for (int i = 1; i <= n; i++)
        {
            double term = 1 + 0.1 * i;
            if (i % 2 == 0)
            {
                result -= term;
            }
            else
            {
                result += term;
            }
        }
        Console.WriteLine(result);
    }
}
﻿using System;

class Program
{
    static void Main()
    {
        Console.Write("Введите целое число n: ");
        int n = Convert.ToInt32(Console.ReadLine());
        int sum = 0;
        for (int i = 0; i <= n; i++)
        {
            sum += (int)Math.Pow(2, i);
        }
        Console.WriteLine(sum);
    }
}
﻿using System;

class Program
{
    static void Main()
    {
        Console.Write("Введите вещественное число A: ");
        double A = Convert.ToDouble(Console.ReadLine());

        Console.Write("Введите целое положительное число N: ");
        int N = Convert.ToInt32(Console.ReadLine());

        double result = 1;
        for (int i = 0; i < N; i++)
        {
            result *= A;
            Console.WriteLine("Текущий результат: " + result);
        }
        Console.WriteLine("Число " + A + " в степени " + N + " равно: " + result);
    }
}
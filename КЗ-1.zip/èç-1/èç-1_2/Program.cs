﻿using System;

class Program
{
    static void Main(string[] args)
    {   
        Console.Write("Введите число n: ");
        int n = Convert.ToInt32(Console.ReadLine());
        for (int i = 0; i <= n; i++)
        {
            Console.WriteLine(i);
        }
    }
}
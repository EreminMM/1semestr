﻿using System;

class Program
{
    static void Main()
    {   
        Console.Write("Введите положительное число A (ширина): ");
        int A = Convert.ToInt32(Console.ReadLine());

        Console.Write("Введите положительное число B (высота): ");
        int B = Convert.ToInt32(Console.ReadLine());

        Console.Write("Введите положительное число C (сторона квадрата): ");
        int C = Convert.ToInt32(Console.ReadLine());
        if (C > A || C > B)
        {
            Console.WriteLine("Квадраты не могут быть размещены.");
            return;
        }
        int countWidth = CountSquares(A, C);
        int countHeight = CountSquares(B, C);
        int totalSquares = MultiplyWithoutMultiplication(countWidth, countHeight);
        Console.WriteLine("Максимально возможное количество квадратов: " + totalSquares);
    }
    static int CountSquares(int dimension, int squareSize)
    {
        int count = 0;
        while (dimension >= squareSize)
        {
            count++;
            dimension -= squareSize;
        }
        return count;
    }
    static int MultiplyWithoutMultiplication(int a, int b)
    {
        int result = 0;
        for (int i = 0; i < a; i++)
        {
            result += b;
        }
        return result;
    }
}
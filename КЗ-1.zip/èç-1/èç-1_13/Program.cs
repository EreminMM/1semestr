﻿using System;

class Program
{
    static void Main()
    {
        Console.Write("Введите число A: ");
        int A = Convert.ToInt32(Console.ReadLine());
        Console.Write("Введите число B: ");
        int B = Convert.ToInt32(Console.ReadLine());

        int gcd = GCD(A, B);

        Console.WriteLine(gcd);
    }
    static int GCD(int a, int b)
    {
        while (b != 0)
        {
            int temp = b;
            b = a % b;
            a = temp;
        }
        return a;
    }
}